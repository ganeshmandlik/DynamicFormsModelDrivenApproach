import {Component} from '@angular/core';

@Component({
    selector: 'app-footer',
    template: `
        <div class="footer clearfix">            
            <span>Copyright © 2019 L&T Infotech Financial Services Technologies Inc.</span>
            <a href="https://www.lntinfotech.com/">Lntinfotech.com</a>
            <a href="https://www.lntinfotech.com/privacy.aspx">Privacy |</a>
            <a href="https://www.lntinfotech.com/industries/Banking_n_finance/banking_N_finance.html">Markets & Banking |</a>

        </div>
    `
})
export class AppFooterComponent {

}
