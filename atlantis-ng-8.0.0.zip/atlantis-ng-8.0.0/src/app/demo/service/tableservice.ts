import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Table} from '../domain/table';

@Injectable()
export class CarService {

    constructor(private http: HttpClient) {}

    getTables() {
        return this.http.get<any>('assets/demo/data/cars-small.json')
                    .toPromise()
                    .then(res => res.data as Table[])
                    .then(data => data);
    }    
}
