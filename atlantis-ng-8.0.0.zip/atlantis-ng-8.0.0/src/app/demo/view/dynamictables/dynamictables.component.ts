import { Component, ViewChild } from "@angular/core";
import { Validators } from "@angular/forms";
import { FieldConfig } from "./../../../field.interface";
import { DynamicFormComponent } from "./../../view/dynamic-form/dynamic-form.component";

@Component({
  selector: 'app-dynamictables',
  template: `
  
  <div style="text-align:center">
    <h1>
      Registration Form
    </h1>
  </div>
  <dynamic-form [fields]="regConfig" (submit)="submit($event)">
  </dynamic-form>
  <div class="margin-top">
    {{ form.value | json }}
  </div>

  `,
  styles: []
})
export class DynamictablesComponent{
  @ViewChild(DynamicFormComponent, {static:true}) form: DynamicFormComponent;
  regConfig: FieldConfig[] = [
    {
      type: "input",
      label: "Username",
      inputType: "text",
      name: "name",
      validations: [
        {
          name: "required",
          validator: Validators.required,
          message: "Name Required"
        },
        {
          name: "pattern",
          validator: Validators.pattern("^[a-zA-Z]+$"),
          message: "Accept only text"
        }
      ]
    },


  ];
  constructor() { }

  ngOnInit() {
  }

}
