export interface Table {
    screencode;
    screendescription;
}